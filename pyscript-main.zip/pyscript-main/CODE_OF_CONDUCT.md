# Code of Conduct

The Code of Conduct is available in the pyscript Governance repo.
See https://github.com/pyscript/governance/blob/main/CODE-OF-CONDUCT.md
